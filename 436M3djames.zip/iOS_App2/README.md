To use the app, you need to have a user id and login. There are 5:

Username (case insensitive)   Password (case sensitive)
-------------------------------------------------------
David                         pass
Hans                          pass
Josh                          pass
Ryan                          pass
Cameron                       pass
------------------------------------------------------

Also I suggest opening two instances of the app at a time to view the real-time updates.


The only missing component right now is background refresh (and debugging).
