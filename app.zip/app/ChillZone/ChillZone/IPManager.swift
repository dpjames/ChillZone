//
//  IPManager.swift
//  ChillZone
//
//  Created by David James on 2/21/18.
//  Copyright © 2018 David James. All rights reserved.
//

import Foundation
class IPManager{
    //static var IP : String = "http://192.168.1.21:4011";
    //static var IP : String = "http://192.168.160.1:4011";
    //static var IP : String = "http://192.168.1.111:4011";
    static var IP : String = "http://35.227.171.161"
    static func createIP(){
        
    }
}
