To use the app, you need to have a user id and login. There are 5:

Username (case insensitive)   Password (case sensitive)
-------------------------------------------------------
David                         pass
Hans                          pass
Josh                          pass
Ryan                          pass
Cameron                       pass
------------------------------------------------------

Also I suggest opening two instances of the app at a time to view the real-time updates. 
These occur on the lights screen and the chat screen.

to clear chore notifications, click on a red chore that the user who is logged in owns. 
The color should change and notifications for that chore should stop.

to clear message notifications open the chat. This updates the last seen message and therefore will stop
notifications until someone sends a newer notification.

I am not sure BG refresh works on its own. It works if you manually trigger it though. 

To test the home status indicators (the red/green bar on peoples names) set the location to (35.2635, -120.6999) 
This will turn the status indicator for the person who is logged in to green. (this does not dynamically update,
you need to reopen the people page from the menu screen). 

